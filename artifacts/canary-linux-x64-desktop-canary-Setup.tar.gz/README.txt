desktop Installer
========================

To install desktop:

1. Double-click the 'installer' file
2. Or run from terminal: ./installer

The installer will:
- Extract the application to ~/.local/share/
- Create a desktop shortcut with the app's icon

For more information, visit: https://electrobun.dev
